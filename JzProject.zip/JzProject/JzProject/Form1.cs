﻿//Yang Rename Anak Ngentod
//Buy Jasa? Dm me JzuvGTI#7245 Discord

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Security.Permissions;
using Microsoft.Win32;

namespace JzProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bunifuLabel1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void udpstart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(udpinput.Text))
            {
                MessageBox.Show("Please Input Port On TextBox", "JzProject", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Process proc = new Process();
            string top = "netsh.exe";
            proc.StartInfo.Arguments = "Advfirewall set privateprofile state off";
            proc.StartInfo.FileName = top;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.CreateNoWindow = true;
            proc.Start();
            proc.WaitForExit();
            Process proc1 = new Process();
            string top1 = "netsh.exe";
            proc1.StartInfo.Arguments = "Advfirewall set publicprofile state off";
            proc1.StartInfo.FileName = top1;
            proc1.StartInfo.UseShellExecute = false;
            proc1.StartInfo.RedirectStandardOutput = true;
            proc1.StartInfo.CreateNoWindow = true;
            proc1.Start();
            proc1.WaitForExit();
            Process proc2 = new Process();
            string top2 = "netsh.exe";
            proc2.StartInfo.Arguments = "firewall add portopening TCP 80 80";
            proc2.StartInfo.FileName = top2;
            proc2.StartInfo.UseShellExecute = false;
            proc2.StartInfo.RedirectStandardOutput = true;
            proc2.StartInfo.CreateNoWindow = true;
            proc2.Start();
            proc2.WaitForExit();
            Process proc3 = new Process();
            string top3 = "netsh.exe";
            proc2.StartInfo.Arguments = "firewall add portopening TCP " + udpinput.Text + " " + udpinput.Text;
            proc2.StartInfo.FileName = top3;
            proc2.StartInfo.UseShellExecute = false;
            proc2.StartInfo.RedirectStandardOutput = true;
            proc2.StartInfo.CreateNoWindow = true;
            proc2.Start();
            proc2.WaitForExit();
            MessageBox.Show("Firewall Has Been Setup!!!", "JzProject", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        private void startmake_Click(object sender, EventArgs e)
        {
            string desktop = Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory);

            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(desktop + @"\" + inputname.Text + ".txt", false))
            {
                file.WriteLine(inputip.Text + " growtopia1.com");
                file.WriteLine(inputip.Text + " growtopia2.com");
                file.WriteLine("#Host Made By JzProject Tools");
                MessageBox.Show("Host Has Been Saved In Desktop", "JzProject", MessageBoxButtons.OK, MessageBoxIcon.Information);              
                return;
            }
        }
        private void JzLoad(object sender, EventArgs e)
        {
            Process[] pname = Process.GetProcessesByName(inputexe.Text);  //if server.exe running
            if (pname.Length > 0)
            {
                label1.Text = ("STATUS SERVER : " + "UP");
                label2.Text = ("STATUS AUTO UP : " + "NO WORK");
            }
            else
            {
                label1.Text = ("STATUS SERVER : " + "DOWN");
                label2.Text = ("STATUS AUTO UP : " + "NO WORK");
            }


        }

        private void startup_Click(object sender, EventArgs e)
        {
            {

                timer1.Enabled = true; //open button
                timer1.Interval = 200;
                label2.Text = ("STATUS AUTO UP : " + "WORKING");

            }
        }

        private void stopup_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;  //stop button
            label2.Text = ("STATUS AUTO UP : " + "NO WORK");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Process[] pname = Process.GetProcessesByName(inputexe.Text);  //if server.exe running
            if (pname.Length > 0)
            {
                label1.Text = ("SERVER STATUS : " + "UP");

            }
            else
            {
                label1.Text = ("SERVER STATUS : " + "DOWN");
                System.Diagnostics.Process.Start(@filepath.Text + "/" + inputexe.Text);  //start server.exe
            }
        }

        private void bunifuPanel2_Click(object sender, EventArgs e)
        {

        }
        private void FileDownloadComplete(object sender, AsyncCompletedEventArgs e)
        {
            MessageBox.Show("Application Has Been Downloaded", "JzProject", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();

            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(FileDownloadComplete);
            Uri imageurl = new Uri("https://visualstudio.microsoft.com/thank-you-downloading-visual-studio/?sku=Community&rel=16");
            wc.DownloadFileAsync(imageurl, "VS-2019-Download-With-JzProject.exe");
        }

        private void bunifuLabel8_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();

            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(FileDownloadComplete);
            Uri imageurl = new Uri("https://www.apachefriends.org/xampp-files/7.3.29/xampp-windows-x64-7.3.29-2-VC15-installer.exe");
            wc.DownloadFileAsync(imageurl, "Xampp-Download-With-JzProject.exe");
        }

        private void bunifuButton3_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();

            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(FileDownloadComplete);
            Uri imageurl = new Uri("https://www.win-rar.com/postdownload.html?&L=0");
            wc.DownloadFileAsync(imageurl, "WINRAR-Download-With-JzProject.exe");
        }

        private void bunifuLabel10_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton4_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();

            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(FileDownloadComplete);
            Uri imageurl = new Uri("https://nodejs.org/dist/v14.17.5/node-v14.17.5-x64.msi");
            wc.DownloadFileAsync(imageurl, "NODENS-Download-With-JzProject.exe");
        }

        private void bunifuLabel11_Click(object sender, EventArgs e)
        {

        }

        private void bunifuPanel3_Click(object sender, EventArgs e)
        {

        }
        private bool mouseDown;
        private Point lastLocation;

        private void bunifuPanel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void bunifuPanel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void bunifuPanel1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }
    }
}
